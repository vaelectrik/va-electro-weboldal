begin;

alter table public.inquiries add column if not exists deleted_at timestamptz;

create or replace function public.set_va_electro_inquiry_deleted(p_inquiry_id text, p_deleted boolean)
returns boolean
language plpgsql
security definer
set search_path = ''
as $function$
begin
  if auth.uid() is null or public.is_va_electro_admin() is distinct from true then
    raise exception 'Adminjogosultság szükséges.' using errcode = '42501';
  end if;
  if p_inquiry_id is null or p_inquiry_id = '' or p_deleted is null then
    raise exception 'Hiányos kérés.' using errcode = '22023';
  end if;

  update public.inquiries as inquiry
  set deleted_at = case
    when p_deleted then coalesce(inquiry.deleted_at, pg_catalog.now())
    else null
  end
  where inquiry.id::text = p_inquiry_id;
  return found;
end;
$function$;

revoke all on function public.set_va_electro_inquiry_deleted(text, boolean) from public, anon, authenticated;
grant execute on function public.set_va_electro_inquiry_deleted(text, boolean) to authenticated;

commit;
