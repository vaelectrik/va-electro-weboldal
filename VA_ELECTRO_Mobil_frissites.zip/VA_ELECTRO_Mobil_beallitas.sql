begin;

alter table public.inquiries
  add column if not exists offer_sent_at timestamptz;

create or replace function public.va_electro_record_offer_sent_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.status = 'offer_sent' then
    if tg_op = 'INSERT' then
      new.offer_sent_at := pg_catalog.statement_timestamp();
    elsif old.status is distinct from new.status then
      new.offer_sent_at := pg_catalog.statement_timestamp();
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists va_electro_offer_sent_at on public.inquiries;
create trigger va_electro_offer_sent_at
before insert or update of status on public.inquiries
for each row execute function public.va_electro_record_offer_sent_at();

create table if not exists public.business_expenses (
  id uuid primary key default gen_random_uuid(),
  note text not null check (char_length(btrim(note)) between 1 and 300),
  amount integer not null check (amount between 1 and 999999999),
  expense_date date not null default ((now() at time zone 'Europe/Budapest')::date),
  created_at timestamptz not null default now()
);

alter table public.business_expenses enable row level security;
revoke all on public.business_expenses from public, anon, authenticated;
grant select on public.business_expenses to authenticated;
grant insert (note, amount) on public.business_expenses to authenticated;

drop policy if exists "VA ELECTRO admin reads expenses" on public.business_expenses;
create policy "VA ELECTRO admin reads expenses"
on public.business_expenses for select to authenticated
using ((select public.is_va_electro_admin()) is true);

drop policy if exists "VA ELECTRO admin adds expenses" on public.business_expenses;
create policy "VA ELECTRO admin adds expenses"
on public.business_expenses for insert to authenticated
with check ((select public.is_va_electro_admin()) is true);

create index if not exists business_expenses_date_order
on public.business_expenses (expense_date desc, created_at desc);

commit;
